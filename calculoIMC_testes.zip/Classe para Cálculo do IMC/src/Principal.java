
public class Principal {

	public static void main(String[] args) {
		Paciente paciente1 = new Paciente(40, 1.8);
		Paciente paciente2 = new Paciente(55, 1.8);
		Paciente paciente3 = new Paciente(58, 1.8);
		Paciente paciente4 = new Paciente(65, 1.8);
		Paciente paciente5 = new Paciente(90, 1.8);
		Paciente paciente6 = new Paciente(110, 1.8);
		Paciente paciente7 = new Paciente(120, 1.8);
		Paciente paciente8 = new Paciente(150, 1.8);
		
		paciente1.diagnostico();
		paciente2.diagnostico();
		paciente3.diagnostico();
		paciente4.diagnostico();
		paciente5.diagnostico();
		paciente6.diagnostico();
		paciente7.diagnostico();
		paciente8.diagnostico();
	}
	
}
