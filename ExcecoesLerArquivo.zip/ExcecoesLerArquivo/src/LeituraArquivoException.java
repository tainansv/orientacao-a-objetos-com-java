
public class LeituraArquivoException extends Exception {

	/**
	 * default serial
	 */
	private static final long serialVersionUID = 1L;

	public LeituraArquivoException(String mensagem) {
		super(mensagem);
	}
}
