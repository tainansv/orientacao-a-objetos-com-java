
public class Principal {

	public static void main(String[] args) {
		Paciente paciente1 = new Paciente(59, 1.7);
		Paciente paciente2 = new Paciente(69, 1.6);
		Paciente paciente3 = new Paciente(110, 1.78);
		
		paciente1.diagnostico();
		
		paciente2.diagnostico();
		
		paciente3.diagnostico();
	}
	
}
